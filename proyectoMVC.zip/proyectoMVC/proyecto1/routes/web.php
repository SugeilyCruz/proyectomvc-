<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\mainContralador;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
  //  return view('welcome');
//});

Route::get('/', [mainContralador::class, 'index']);

Route::get('/holaUrl', [mainContralador::class, 'holamundo']);
Route::get('/crearnuevopais', [mainContralador::class, 'crearEjemplo']);

//formulario para crear paises
Route::get('/crear-pais', [mainContralador::class, 'crearPais']);
//enviar fatos desde el formulario
Route::post('/postPais', [mainContralador::class, 'postPais']);
//eliminar pais
Route::get('/eliminar-pais/{id}', [mainContralador::class, 'eliminarPais']);
//Editar pais front
Route::get('/editar-pais/{id}', [mainContralador::class, 'editarPais']);
//updated pais
Route::post('/updated-pais', [mainContralador::class, 'updatedPais']);
