<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>hola visa</title>
  </head>
  <body>
    <h1>Hola desde la vista</h1>
    <a type="button"  href="http://127.0.0.1:8000/crear-pais" class="btn btn-primary">Crear pais</a>
 <table class="table">
   <thead>
      <tr>
         <th scope="col">id</th>
         <th scope="col">nombre</th>
         <th scope="col">descripcion</th>
         <th scope="col">status</th>
         <th scope="col">Acciones</th>
     </tr>
   </thead>
 <tbody>
   <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
       <th scope="row"><?php echo e($p->id); ?></th>
       <td><?php echo e($p->nombre); ?></td>
       <td><?php echo e($p->descripcion); ?></td>
       <td><?php echo e($p->status); ?></td>
       <td><a href="http://127.0.0.1:8000/eliminar-pais/<?php echo e($p->id); ?>">eliminar</a>
          <a  target="_blank" href="http://127.0.0.1:8000/editar-pais/<?php echo e($p->id); ?>">editar pais</a>
       </td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    -->
  </body>
</html>
<?php /**PATH C:\Users\Caligula666\Documents\proyectoMVC\proyecto1\resources\views/welcome.blade.php ENDPATH**/ ?>