<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cat_pais extends Model
{
    use HasFactory;
    //tabla a la que se conetca mi modelo
    protected $table = 'cat_paises';
    //variables que se autllenan
    protected $fillable =
    [
        'nombre',
        'descripcion',
        'status',
    ];
    
}
