<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\cat_pais;
use Illuminate\Support\Facades\Validator;
class mainApiController extends Controller
{
    //funcion de prueba tipo get deszde una api
    public function holaEjemplo(){
      $paises = cat_pais::get();
      return $paises;
    }

    //funcion tipo post
    public function ejemploPost(Request $request){
      //validdor de nuestra api
      $validator = Validator::make($request->all(), [
        'nombre'      =>  'required|min:10|max:50',
        'descripcion' =>  'required',
      ]);
      //si hay errores envia errores
      if ($validator->fails())
        return $validator->messages();
      //crea un nuevo pais
        $pais = new cat_pais;
        $pais->fill($request->all());
        $pais->status = 1;
        $pais->save();
      return 1;
    }

}
