<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\cat_pais;

class mainContralador extends Controller
{
    //funcion de prueba
    public function holamundo()
    {
      //SELECT * FROM `cat_paises`
      //$paises = cat_pais::get();
      // select * from `cat_paises` where id = 1;
      $pais1 = cat_pais::where('id','=',1)->first();
      dd($pais1->descripcion);
      //dd("hola mundo");
    }

    //funcion del index
    public function index(){
      $paises = cat_pais::get();
      return view( 'welcome',
      [
      'paises' => $paises
      ]
     );
    }

    //funcion creacion de otro pais
    public function crearEjemplo(){
      //INSERT INTO cat_paises VALUES ( "nombre pais", "descripcion del pais","1");
      $nuevapais = new cat_pais();
      $nuevapais->nombre = "nuevo pais";
      $nuevapais->descripcion = "descripcion del pais";
      $nuevapais->status = 1;
      $nuevapais->save();
      dd($nuevapais);
    }


    //funcion de la vista de crear un paise
    public function crearPais(){
      return view('crear');
    }
    //funcion para crear un nievo pais post
    public function postPais(Request $request){
      $validated = $request->validate([
       'nombre'      =>  'required|min:10|max:50',
       'descripcion' =>  'required',
      ]);

      $pais = new cat_pais;
      $pais->fill($request->all());
      /*
      $pais->nombre = $request->nombre;
      $pais->descripcion = $request->descripcion;
      */
      $pais->status = 1;
      $pais->save();
      //return redirect()->route('projects.index');
      return redirect('/');
      //dd("registro guardado satisfactoriamente");
    }

    //funcion para eliminar pais
    public function eliminarPais($id){
      //select * from cat_paises where id = $id
      $paiseliminar = cat_pais::find($id);
     if($paiseliminar!=null)
      $paiseliminar->delete();
      return redirect('/');
      //dd($paiseliminar);
    }
    // funcion para editar el pais
    public function editarPais($id){
      //crear una nueva isntancia del objeto paises pero con buesqueda
      $paisEdit = cat_pais::find($id);
      return view( 'edit',
      [
      'pais' => $paisEdit
      ]
     );
      //dd($paisEdit);
    }

    //funcion para actualizar datos
    public function updatedPais(Request $request){
      $validated = $request->validate([
       'nombre'      =>  'required|min:10|max:50',
       'descripcion' =>  'required',
      ]);
      $updatedPais = cat_pais::find($request->id);
      $updatedPais->fill($request->all());
      /*$updatedPais->nombre = $request->nombre;
      $updatedPais->descripcion = $request->descripcion;*/
      //$updatedPais->updated($request->all());
      $updatedPais->save();
      return redirect('/');
    }


}
